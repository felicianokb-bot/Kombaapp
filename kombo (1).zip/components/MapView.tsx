import React from 'react';
import { MapPin, Navigation } from 'lucide-react';
import { MOCK_SERVICES } from '../constants';
import { Language } from '../types';

interface MapViewProps {
  lang: Language;
}

// Since we cannot ensure Leaflet assets load perfectly in all environments without build steps,
// we create a high-fidelity visual mock using a styled background and absolute positioning.
const MapView: React.FC<MapViewProps> = ({ lang }) => {
  return (
    <div className="relative w-full h-full bg-blue-50 dark:bg-gray-900 overflow-hidden transition-colors duration-200">
      {/* Simulated Map Background - Using a blurred stylistic representation */}
      <div 
        className="absolute inset-0 opacity-40 dark:opacity-20 bg-cover bg-center" 
        style={{ backgroundImage: 'url("https://picsum.photos/800/1200?grayscale&blur=2")' }}
      ></div>
      
      {/* Grid lines to look like a map */}
      <div className="absolute inset-0" style={{ 
        backgroundImage: 'linear-gradient(#cbd5e1 1px, transparent 1px), linear-gradient(90deg, #cbd5e1 1px, transparent 1px)', 
        backgroundSize: '40px 40px',
        opacity: 0.3
      }}></div>

      {/* Dark Mode Overlay for Map */}
      <div className="absolute inset-0 bg-transparent dark:bg-slate-900/40 pointer-events-none transition-colors duration-200"></div>

      {/* Map UI Overlays */}
      <div className="absolute top-4 left-4 right-4 z-10">
        <div className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-md p-3 rounded-xl shadow-lg border border-white/50 dark:border-gray-700/50 flex items-center gap-3 transition-colors">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
          <span className="text-sm font-semibold text-gray-700 dark:text-gray-200">
            {lang === 'pt' ? 'A procurar perto de Luanda...' : 'Searching near Luanda...'}
          </span>
        </div>
      </div>

      {/* Simulated Markers */}
      {/* User Location */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
        <div className="w-16 h-16 bg-blue-500/20 dark:bg-blue-400/20 rounded-full flex items-center justify-center animate-ping absolute"></div>
        <div className="w-4 h-4 bg-blue-600 dark:bg-blue-400 border-2 border-white dark:border-gray-900 rounded-full shadow-lg relative z-10"></div>
      </div>

      {/* Service Pins */}
      {MOCK_SERVICES.map((service, index) => {
        // Random positions for demo
        const top = 30 + (index * 20) + '%'; 
        const left = 20 + (index * 30) + '%';
        
        return (
          <div key={service.id} className="absolute flex flex-col items-center group cursor-pointer" style={{ top, left }}>
             <div className="bg-white dark:bg-gray-800 px-2 py-1 rounded-md shadow-md mb-1 opacity-0 group-hover:opacity-100 transition-opacity text-xs font-bold whitespace-nowrap z-20 text-gray-800 dark:text-gray-200">
              {service.businessName}
            </div>
            <div className="text-orange-500 drop-shadow-md hover:scale-125 transition-transform">
              <MapPin size={32} fill="currentColor" />
            </div>
          </div>
        );
      })}

      {/* Trip Pins */}
      <div className="absolute top-[25%] left-[60%] flex flex-col items-center">
         <div className="bg-indigo-600 text-white text-[10px] px-2 py-1 rounded-full shadow-lg mb-1">
           {lang === 'pt' ? 'Viagem p/ Benguela' : 'Trip to Benguela'}
         </div>
         <Navigation size={24} className="text-indigo-600 fill-current rotate-45" />
      </div>

      {/* Floating Action Button */}
      <button className="absolute bottom-24 right-4 w-12 h-12 bg-white dark:bg-gray-800 rounded-full shadow-xl flex items-center justify-center text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
        <Navigation size={20} />
      </button>
    </div>
  );
};

export default MapView;