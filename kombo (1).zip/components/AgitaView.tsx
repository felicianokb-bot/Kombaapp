
import React, { useState } from 'react';
import { Search, MapPin, Calendar, Package, ArrowRight, UserCheck, Filter, Plane, Bus, Ship, Car, Truck, Info, Clock, Weight, MessageCircle } from 'lucide-react';
import { TEXT } from '../constants';
import { generateTripAdvice } from '../services/geminiService';
import { Language, TransportType, CapacityUnit, Trip } from '../types';

interface AgitaViewProps {
  lang: Language;
  trips: Trip[];
  onAddTrip: (trip: Trip) => void;
  onChat: (userId: string, userName: string, context: string) => void;
}

const AgitaView: React.FC<AgitaViewProps> = ({ lang, trips, onAddTrip, onChat }) => {
  const [activeTab, setActiveTab] = useState<'find' | 'post'>('find');
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [searchDate, setSearchDate] = useState('');
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [loadingAdvice, setLoadingAdvice] = useState(false);
  
  // Post Trip Form State
  const [postOrigin, setPostOrigin] = useState('');
  const [postDestination, setPostDestination] = useState('');
  const [transportType, setTransportType] = useState<TransportType>('car');
  const [capacity, setCapacity] = useState('');
  const [capacityUnit, setCapacityUnit] = useState<CapacityUnit>('kg');
  const [price, setPrice] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [description, setDescription] = useState('');

  const t = TEXT[lang];

  // Filtering Logic
  const filteredTrips = trips.filter(trip => {
    const matchOrigin = origin ? trip.origin.toLowerCase().includes(origin.toLowerCase()) : true;
    const matchDest = destination ? trip.destination.toLowerCase().includes(destination.toLowerCase()) : true;
    const matchDate = searchDate ? trip.date === searchDate : true;
    return matchOrigin && matchDest && matchDate;
  });

  const handleSearch = async () => {
    if (origin && destination) {
      setLoadingAdvice(true);
      const advice = await generateTripAdvice(origin, destination, lang);
      setAiAdvice(advice);
      setLoadingAdvice(false);
    }
  };

  const handlePublish = () => {
    if (!postOrigin || !postDestination || !date || !price) return;

    const newTrip: Trip = {
      id: Date.now().toString(),
      hostId: 'me', // Will be overwritten in App.tsx with real user ID
      origin: postOrigin,
      destination: postDestination,
      date,
      time,
      transportType,
      capacity: Number(capacity),
      capacityUnit,
      pricePerUnit: Number(price),
      currency: 'Kz',
      description,
      status: 'active'
    };

    onAddTrip(newTrip);
  };

  const getTransportIcon = (type: string) => {
    switch (type) {
      case 'plane': return <Plane size={18} />;
      case 'bus': return <Bus size={18} />;
      case 'boat': return <Ship size={18} />;
      case 'truck': return <Truck size={18} />;
      default: return <Car size={18} />;
    }
  };

  return (
    <div className="flex flex-col md:flex-row h-full bg-gray-50 dark:bg-gray-900 md:p-6 md:gap-6 transition-colors duration-200">
      
      {/* Sidebar: Toggle between Find and Post */}
      <div className="w-full md:w-96 bg-white dark:bg-gray-800 md:rounded-2xl md:shadow-sm md:border md:border-gray-200 dark:md:border-gray-700 md:h-fit sticky top-0 md:static z-10 shrink-0 transition-colors">
        
        {/* Toggle Tabs */}
        <div className="p-4 border-b border-gray-100 dark:border-gray-700">
           <div className="flex bg-gray-100 dark:bg-gray-700 p-1 rounded-xl">
            <button 
              onClick={() => setActiveTab('find')}
              className={`flex-1 py-3 text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${activeTab === 'find' ? 'bg-white dark:bg-gray-600 text-blue-600 dark:text-blue-300 shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'}`}
            >
              <Search size={16} />
              {t.findTrip}
            </button>
            <button 
              onClick={() => setActiveTab('post')}
              className={`flex-1 py-3 text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${activeTab === 'post' ? 'bg-white dark:bg-gray-600 text-orange-600 dark:text-orange-300 shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'}`}
            >
              <Package size={16} />
              {t.postTrip}
            </button>
          </div>
        </div>

        {/* Content Area based on Tab */}
        <div className="p-4 md:p-6 space-y-5">
          
          {activeTab === 'find' ? (
            /* FIND TRIP FORM */
            <>
               <div className="space-y-1">
                 <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide ml-1">{t.from}</label>
                 <div className="relative">
                  <MapPin className="absolute left-3 top-3.5 text-blue-500" size={18} />
                  <input 
                    type="text" 
                    placeholder="Ex: Luanda" 
                    value={origin}
                    onChange={(e) => setOrigin(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-gray-800 dark:text-white transition-all font-medium"
                  />
                </div>
              </div>
              
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide ml-1">{t.to}</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3.5 text-orange-500" size={18} />
                  <input 
                    type="text" 
                    placeholder="Ex: Benguela" 
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 text-gray-800 dark:text-white transition-all font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide ml-1">{t.date}</label>
                    <input 
                      type="date" 
                      value={searchDate}
                      onChange={(e) => setSearchDate(e.target.value)}
                      className="w-full mt-1 px-3 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm focus:outline-none focus:border-blue-500 text-gray-600 dark:text-gray-200 font-medium" 
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide ml-1">{t.transportType}</label>
                    <select className="w-full mt-1 px-3 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm focus:outline-none focus:border-blue-500 text-gray-600 dark:text-gray-200 font-medium appearance-none">
                      <option value="all">Todos</option>
                      <option value="car">Carro</option>
                      <option value="bus">Autocarro</option>
                      <option value="truck">Camião</option>
                    </select>
                  </div>
              </div>

              <button 
                onClick={handleSearch}
                className="w-full bg-blue-600 text-white py-3.5 rounded-xl font-bold shadow-lg shadow-blue-600/20 hover:bg-blue-700 active:scale-[0.98] transition-all flex items-center justify-center gap-2 mt-4"
              >
                <Search size={18} />
                {loadingAdvice ? t.analyzing : t.searchBtn}
              </button>
            </>
          ) : (
            /* POST TRIP FORM */
            <>
              <div className="bg-orange-50 dark:bg-orange-900/20 p-3 rounded-lg border border-orange-100 dark:border-orange-900/40 flex gap-2 mb-2">
                 <Info size={16} className="text-orange-500 shrink-0 mt-0.5" />
                 <p className="text-xs text-orange-700 dark:text-orange-300 leading-snug">
                   {lang === 'pt' ? 'Ganhe dinheiro extra levando encomendas na sua viagem.' : 'Earn extra money carrying packages on your trip.'}
                 </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                 <div className="space-y-1">
                   <label className="text-[10px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide ml-1">{t.from}</label>
                   <input 
                      type="text" 
                      className="w-full px-3 py-2.5 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm focus:border-orange-500 outline-none text-gray-800 dark:text-white" 
                      placeholder="Origem"
                      value={postOrigin}
                      onChange={(e) => setPostOrigin(e.target.value)}
                   />
                 </div>
                 <div className="space-y-1">
                   <label className="text-[10px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide ml-1">{t.to}</label>
                   <input 
                      type="text" 
                      className="w-full px-3 py-2.5 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm focus:border-orange-500 outline-none text-gray-800 dark:text-white" 
                      placeholder="Destino" 
                      value={postDestination}
                      onChange={(e) => setPostDestination(e.target.value)}
                   />
                 </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                 <div className="space-y-1">
                   <label className="text-[10px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide ml-1">{t.date}</label>
                   <div className="relative">
                      <Calendar size={14} className="absolute left-3 top-3 text-gray-400" />
                      <input 
                        type="date" 
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full pl-9 pr-2 py-2.5 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm focus:border-orange-500 outline-none text-gray-800 dark:text-white" 
                      />
                   </div>
                 </div>
                 <div className="space-y-1">
                   <label className="text-[10px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide ml-1">{t.time}</label>
                   <div className="relative">
                      <Clock size={14} className="absolute left-3 top-3 text-gray-400" />
                      <input 
                        type="time" 
                        value={time}
                        onChange={(e) => setTime(e.target.value)}
                        className="w-full pl-9 pr-2 py-2.5 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm focus:border-orange-500 outline-none text-gray-800 dark:text-white" 
                      />
                   </div>
                 </div>
              </div>

              {/* Transport Selection */}
              <div className="space-y-2">
                 <label className="text-[10px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide ml-1">{t.transportType}</label>
                 <div className="grid grid-cols-4 gap-2">
                    {(['car', 'bus', 'truck', 'plane'] as TransportType[]).map((type) => (
                      <button 
                        key={type}
                        onClick={() => setTransportType(type)}
                        className={`flex flex-col items-center justify-center py-2 rounded-lg border transition-all ${transportType === type ? 'bg-orange-50 dark:bg-orange-900/30 border-orange-500 text-orange-600 dark:text-orange-400' : 'bg-white dark:bg-gray-700 border-gray-200 dark:border-gray-600 text-gray-400 hover:border-gray-300 dark:hover:border-gray-500'}`}
                      >
                         {getTransportIcon(type)}
                         <span className="text-[9px] font-bold uppercase mt-1">{type}</span>
                      </button>
                    ))}
                 </div>
              </div>

              {/* Capacity & Price */}
              <div className="grid grid-cols-2 gap-3">
                 <div className="space-y-1">
                   <label className="text-[10px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide ml-1">{t.capacity}</label>
                   <div className="flex">
                      <input 
                        type="number" 
                        placeholder="20" 
                        value={capacity}
                        onChange={(e) => setCapacity(e.target.value)}
                        className="w-full pl-3 pr-1 py-2.5 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-l-xl text-sm focus:border-orange-500 outline-none text-gray-800 dark:text-white" 
                      />
                      <select 
                        value={capacityUnit}
                        onChange={(e) => setCapacityUnit(e.target.value as CapacityUnit)}
                        className="bg-gray-100 dark:bg-gray-600 border border-l-0 border-gray-200 dark:border-gray-600 rounded-r-xl text-xs font-bold px-2 text-gray-600 dark:text-gray-300 outline-none"
                      >
                        <option value="kg">kg</option>
                        <option value="liters">L</option>
                        <option value="items">Item</option>
                      </select>
                   </div>
                 </div>
                 <div className="space-y-1">
                   <label className="text-[10px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide ml-1">{t.price} / un</label>
                   <div className="relative">
                      <span className="absolute left-3 top-2.5 text-xs font-bold text-gray-400">Kz</span>
                      <input 
                        type="number" 
                        placeholder="500" 
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        className="w-full pl-8 pr-2 py-2.5 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm focus:border-orange-500 outline-none text-gray-800 dark:text-white" 
                      />
                   </div>
                 </div>
              </div>

              <div className="space-y-1">
                 <label className="text-[10px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide ml-1">{t.description}</label>
                 <textarea 
                    rows={2}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder={lang === 'pt' ? "Ex: Saio da Maianga. Tenho espaço na mala." : "Ex: Leaving from Maianga. Trunk space available."}
                    className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-xl text-sm focus:border-orange-500 outline-none resize-none text-gray-800 dark:text-white"
                 />
              </div>

              <button 
                onClick={handlePublish}
                className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white py-3.5 rounded-xl font-bold shadow-lg shadow-orange-500/20 hover:from-orange-600 hover:to-red-600 active:scale-[0.98] transition-all flex items-center justify-center gap-2 mt-2"
              >
                <Package size={18} />
                {t.publishBtn}
              </button>
            </>
          )}

        </div>
      </div>

      {/* Main Results Area */}
      <div className="flex-1 p-4 md:p-0 overflow-y-auto pb-20 md:pb-0">
        
        {/* Desktop Filter Bar */}
        <div className="hidden md:flex items-center justify-between mb-6 bg-white dark:bg-gray-800 p-3 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm transition-colors">
           <div className="flex gap-2">
             <button onClick={() => { setOrigin(''); setDestination(''); setSearchDate(''); }} className="px-4 py-1.5 rounded-lg bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 text-sm font-semibold shadow-md transition-all">Todos</button>
             <button className="px-4 py-1.5 rounded-lg bg-white dark:bg-gray-700 text-gray-500 dark:text-gray-300 text-sm font-semibold hover:bg-gray-50 dark:hover:bg-gray-600 border border-transparent hover:border-gray-200 dark:hover:border-gray-600 transition-colors flex items-center gap-2"><Car size={14}/> Carro</button>
             <button className="px-4 py-1.5 rounded-lg bg-white dark:bg-gray-700 text-gray-500 dark:text-gray-300 text-sm font-semibold hover:bg-gray-50 dark:hover:bg-gray-600 border border-transparent hover:border-gray-200 dark:hover:border-gray-600 transition-colors flex items-center gap-2"><Plane size={14}/> Avião</button>
           </div>
           <div className="flex items-center gap-2 text-gray-500 dark:text-gray-400 text-sm font-medium px-2 cursor-pointer hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
             <Filter size={16} />
             <span>Filtros Avançados</span>
           </div>
        </div>

        {/* AI Advice */}
        {aiAdvice && (
          <div className="mb-6 bg-gradient-to-r from-indigo-50 to-blue-50 dark:from-indigo-900/30 dark:to-blue-900/30 p-4 md:p-5 rounded-2xl border border-blue-100 dark:border-blue-800 animate-in fade-in slide-in-from-top-2 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-bold uppercase text-blue-600 dark:text-blue-300 tracking-wider bg-blue-100 dark:bg-blue-900/50 px-2 py-0.5 rounded-md">{t.aiLabel}</span>
            </div>
            <p className="text-sm md:text-base text-gray-700 dark:text-gray-200 leading-relaxed font-medium italic">"{aiAdvice}"</p>
          </div>
        )}

        <div className="flex justify-between items-center mb-4 px-1">
           <h3 className="text-sm md:text-lg font-bold text-gray-700 dark:text-gray-300 uppercase md:normal-case tracking-wide">{t.availableTrips} <span className="text-gray-400 font-normal ml-1">({filteredTrips.length})</span></h3>
        </div>

        {/* Results Grid */}
        {filteredTrips.length === 0 ? (
           <div className="flex flex-col items-center justify-center py-20 text-gray-400">
              <Package size={48} className="mb-4 opacity-50" />
              <p>Nenhuma viagem encontrada para esta rota.</p>
           </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredTrips.map((trip) => (
              <div key={trip.id} className="bg-white dark:bg-gray-800 p-5 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 hover:shadow-lg hover:border-blue-100 dark:hover:border-blue-900 transition-all group flex flex-col h-full relative overflow-hidden">
                
                {/* Transport Icon Watermark */}
                <div className="absolute -right-6 -top-6 text-gray-50 dark:text-gray-700/50 opacity-50 rotate-12 group-hover:scale-110 transition-transform">
                  {React.cloneElement(getTransportIcon(trip.transportType) as React.ReactElement<any>, { size: 120 })}
                </div>

                <div className="flex justify-between items-start mb-4 relative z-10">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <img src={trip.host?.avatar} alt={trip.host?.name} className="w-12 h-12 rounded-full object-cover border-2 border-gray-50 dark:border-gray-700 shadow-sm" />
                      {trip.host?.verified && (
                        <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white p-0.5 rounded-full border-2 border-white dark:border-gray-800">
                          <UserCheck size={10} />
                        </div>
                      )}
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-800 dark:text-white text-base">{trip.host?.name}</h4>
                      <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400 font-medium">
                        <span className="flex items-center gap-0.5 text-orange-500 bg-orange-50 dark:bg-orange-900/20 px-1.5 py-0.5 rounded-md">
                          <span className="text-sm">★</span> {trip.host?.rating || 5.0}
                        </span>
                        <span className="uppercase text-[10px] bg-gray-100 dark:bg-gray-700 px-1.5 py-0.5 rounded-md text-gray-500 dark:text-gray-300">{trip.transportType}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="block text-xl font-bold text-blue-600 dark:text-blue-400">{trip.currency} {trip.pricePerUnit.toLocaleString()}</span>
                    <span className="text-xs text-gray-400 dark:text-gray-500 font-medium bg-gray-50 dark:bg-gray-700 px-2 py-1 rounded-full">/ {trip.capacityUnit}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 mb-4 bg-gray-50 dark:bg-gray-750 p-3 rounded-xl border border-gray-100 dark:border-gray-600 relative z-10">
                  <div className="flex-1 text-center overflow-hidden">
                    <span className="block text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-0.5">{t.from}</span>
                    <span className="font-bold text-gray-700 dark:text-gray-200 text-sm truncate block">{trip.origin}</span>
                  </div>
                  <ArrowRight size={18} className="text-gray-300 dark:text-gray-600 shrink-0" />
                  <div className="flex-1 text-center overflow-hidden">
                    <span className="block text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-0.5">{t.to}</span>
                    <span className="font-bold text-gray-700 dark:text-gray-200 text-sm truncate block">{trip.destination}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs text-gray-500 mb-4 relative z-10">
                  <div className="flex items-center gap-2 bg-white dark:bg-gray-700 border border-gray-100 dark:border-gray-600 p-2 rounded-lg">
                      <Calendar size={14} className="text-blue-500" />
                      <span className="font-medium text-gray-600 dark:text-gray-300">{trip.date} • {trip.time}</span>
                  </div>
                  <div className="flex items-center gap-2 bg-white dark:bg-gray-700 border border-gray-100 dark:border-gray-600 p-2 rounded-lg">
                      <Weight size={14} className="text-orange-500" />
                      <span className="font-medium text-gray-600 dark:text-gray-300">{trip.capacity} {trip.capacityUnit} disp.</span>
                  </div>
                </div>
                
                <div className="mt-auto pt-4 border-t border-gray-50 dark:border-gray-700 flex gap-3 relative z-10">
                  <button 
                    onClick={() => onChat(trip.hostId, trip.host?.name || 'Motorista', `Olá, vi a tua viagem de ${trip.origin} para ${trip.destination}.`)}
                    className="flex-1 py-2.5 text-sm font-bold text-blue-600 dark:text-blue-300 bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 dark:hover:bg-blue-900/40 rounded-xl transition-colors flex items-center justify-center gap-2"
                  >
                     <MessageCircle size={16} /> Chat
                  </button>
                  <button className="flex-[2] py-2.5 text-sm font-bold text-white bg-gray-900 dark:bg-blue-600 hover:bg-black dark:hover:bg-blue-700 rounded-xl transition-colors shadow-lg shadow-gray-200 dark:shadow-none">
                    {lang === 'pt' ? 'Reservar Lugar' : 'Book Space'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AgitaView;
